from flask import Flask, request, jsonify
import fitz

app = Flask(__name__)

@app.route('/extract_text', methods=['POST'])
def extract_text():
    f = request.files.get('file')
    if not f:
        return jsonify({"error": "no file"}), 400
    doc = fitz.open(stream=f.read(), filetype="pdf")
    text = ""
    for i, page in enumerate(doc):
        text += f"\n--- PAGE {i+1} ---\n"
        text += page.get_text()
    return jsonify({"text": text})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
